<!doctype html>
<html>
<head>
<meta charset="gb2312">
<title>�ޱ����ĵ�</title>
</head>

<body>
<img src="../server.php" alt=""/>
</body>
</html>
<?php
require('../server.php');

?>