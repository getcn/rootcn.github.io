<?php
if (!isset ($_SESSION)) {
	ob_start();
	session_start();
}
 $hostname="localhost"; //mysql地址
 $basename="root"; //mysql用户名
 $basepass="root"; //mysql密码
 $database="wz"; //mysql数据库名称
?>
<?php
$con=mysql_connect($hostname,$basename,$basepass);
if(!$con) {
	die('数据库连接失败：'.mysql_error());
}
mysql_select_db($database,$con);
?>

<?php

 $conn=mysql_connect($hostname,$basename,$basepass)or die("error!"); //连接mysql              
 mysql_select_db($database,$conn); //选择mysql数据库
mysql_query("set names 'utf8'");//mysql编码
 error_reporting(0);
?>
