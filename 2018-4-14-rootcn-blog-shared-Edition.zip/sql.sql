-- phpMyAdmin SQL Dump
-- version 4.4.15.8
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2018-01-30 19:10:40
-- 服务器版本： 10.1.29-MariaDB
-- PHP Version: 7.0.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ceshi1`
--

-- --------------------------------------------------------

--
-- 表的结构 `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `id` int(4) NOT NULL,
  `name` varchar(100) NOT NULL,
  `content` longtext NOT NULL,
  `time` varchar(500) NOT NULL,
  `name_author` varchar(500) NOT NULL,
  `content_Label` varchar(500) NOT NULL,
  `content_Keyword` varchar(500) NOT NULL,
  `content_Explain` varchar(500) NOT NULL,
  `content_time` varchar(100) NOT NULL,
  `content_Encryptedpassword` varchar(100) NOT NULL,
  `content_jiamiwenzi` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `book`
--

INSERT INTO `book` (`id`, `name`, `content`, `time`, `name_author`, `content_Label`, `content_Keyword`, `content_Explain`, `content_time`, `content_Encryptedpassword`, `content_jiamiwenzi`) VALUES
(1, '程序猿的苦恼', '<!--支持大部分格式显示代码--><blockquote><h1 style="font-size: 32px; font-weight: bold; border-bottom: 2px solid rgb(204, 204, 204); padding: 0px 4px 0px 0px; text-align: center; margin: 16px 0px; line-height: normal;"><span style="border: 1px solid rgb(0, 0, 0);"><strong>这是一个基本页面</strong><strong><img src="http://img.baidu.com/hi/jx2/j_0037.gif"/></strong></span></h1><p><br/></p><h1 style="font-size: 32px; font-weight: bold; border-bottom: 2px solid rgb(204, 204, 204); padding: 0px 4px 0px 0px; text-align: center; margin: 16px 0px; line-height: normal;"><span style="border: 1px solid rgb(0, 0, 0);"><strong><img src="http://img.baidu.com/hi/jx2/j_0041.gif"/>但会受到限制</strong></span></h1><h1 style="font-size: 32px; font-weight: bold; border-bottom: 2px solid rgb(204, 204, 204); padding: 0px 4px 0px 0px; text-align: center; margin: 16px 0px; line-height: normal;"><span style="border: 1px solid rgb(0, 0, 0);"><strong>目前正在努力修改中</strong></span></h1><h1 style="font-size: 32px; font-weight: bold; border-bottom: 2px solid rgb(204, 204, 204); padding: 0px 4px 0px 0px; text-align: center; margin: 16px 0px; line-height: normal;"><span style="border: 1px solid rgb(0, 0, 0);"><strong><img src="http://img.baidu.com/hi/jx2/j_0035.gif"/></strong></span><br/></h1><h1 style="font-size: 32px; font-weight: bold; border-bottom: 2px solid rgb(204, 204, 204); padding: 0px 4px 0px 0px; text-align: center; margin: 16px 0px; line-height: normal;"><span style="border: 1px solid rgb(0, 0, 0);"><strong>这可能只是时间上的问题</strong><br/></span></h1><p><br/></p><h1 style="white-space: normal; font-size: 32px; border-bottom: 2px solid rgb(204, 204, 204); padding: 0px 4px 0px 0px; text-align: center; margin: 16px 0px; line-height: normal;"><span style="border: 1px solid rgb(0, 0, 0);"><strong>希望您能用得习惯</strong></span></h1></blockquote>', '2017-07-27 17:45:39 ', 'admin', '程序猿的苦恼', '程序猿的苦恼', '程序猿的苦恼', '', '0', '0');

-- --------------------------------------------------------

--
-- 表的结构 `homefirst`
--

CREATE TABLE IF NOT EXISTS `homefirst` (
  `id` varchar(10) NOT NULL,
  `homeTitle` varchar(200) NOT NULL,
  `homeSubtitle` varchar(200) NOT NULL,
  `homecopyright` varchar(200) NOT NULL,
  `homeicp` varchar(200) NOT NULL,
  `homekeywords` varchar(200) NOT NULL,
  `homedescription` varchar(200) NOT NULL,
  `homeClose` varchar(50) NOT NULL,
  `homeie6789` varchar(50) NOT NULL,
  `homediqu` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `homefirst`
--

INSERT INTO `homefirst` (`id`, `homeTitle`, `homeSubtitle`, `homecopyright`, `homeicp`, `homekeywords`, `homedescription`, `homeClose`, `homeie6789`, `homediqu`) VALUES
('1', 'Rootcn.cn blog', 'Welcome to rootcn blog', '©<strong>技术支持：</strong><a href="http://rootcn.cn/">Roocn.cn</a>', '1', 'Rootcn.cn-最新消息：主要来自Roocn.cn所发布的文章内容', 'Rootcn.cn-最新消息：主要来自Roocn.cn所发布的文章内容', '1', '0', 'CN');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(4) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_cook` varchar(300) NOT NULL,
  `user_developers` varchar(100) NOT NULL,
  `user_mail` varchar(500) NOT NULL,
  `user_qq` varchar(100) NOT NULL,
  `user_phone` varchar(100) NOT NULL,
  `user_groups` varchar(100) NOT NULL,
  `user_time` varchar(100) NOT NULL,
  `user_thename` varchar(50) NOT NULL,
  `user_sex` varchar(50) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `user_cook`, `user_developers`, `user_mail`, `user_qq`, `user_phone`, `user_groups`, `user_time`, `user_thename`, `user_sex`) VALUES
(1, '123456', 'e10adc3949ba59abbe56e057f20f883e', '', '开发者', '', '', '', '管理组', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homefirst`
--
ALTER TABLE `homefirst`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
