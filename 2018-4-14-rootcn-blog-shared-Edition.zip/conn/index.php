<script>location='../index.php';</script>

