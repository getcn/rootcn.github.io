<?php
@session_start();
/* if(!isset($_SESSION['username'])){
	echo "<script>location.href='admin.php';</script>";
	exit();
} */
?>