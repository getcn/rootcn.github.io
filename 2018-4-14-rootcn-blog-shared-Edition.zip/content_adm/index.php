<?php
echo "<script>location='../index.php';</script>";
?>