<script>location='../../zc/zc.php?tj=register';</script>

